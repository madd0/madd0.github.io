﻿//-----------------------------------------------------------------------
// <copyright file="PercentageColor.cs" company="Madd0">
//     Copyright (c) Mauricio Diaz Orlich (madd0@madd0.com). All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace PercentageColorDemo
{
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Media;

    public static class PercentageColor
    {
        // Using a DependencyProperty as the backing store for Color1.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty Color1Property =
            DependencyProperty.RegisterAttached("Color1", typeof(Color), typeof(PercentageColor), new UIPropertyMetadata(Colors.Black, OnPropertyChanged));

        // Using a DependencyProperty as the backing store for Color2.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty Color2Property =
            DependencyProperty.RegisterAttached("Color2", typeof(Color), typeof(PercentageColor), new UIPropertyMetadata(Colors.Red, OnPropertyChanged));

        // Using a DependencyProperty as the backing store for Percentage.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PercentageProperty =
            DependencyProperty.RegisterAttached("Percentage", typeof(float), typeof(PercentageColor), new UIPropertyMetadata(0f, OnPropertyChanged));

        public static Color GetColor1(DependencyObject obj)
        {
            return (Color)obj.GetValue(Color1Property);
        }

        public static void SetColor1(DependencyObject obj, Color value)
        {
            obj.SetValue(Color1Property, value);
        }

        public static Color GetColor2(DependencyObject obj)
        {
            return (Color)obj.GetValue(Color2Property);
        }

        public static void SetColor2(DependencyObject obj, Color value)
        {
            obj.SetValue(Color2Property, value);
        }

        public static float GetPercentage(DependencyObject obj)
        {
            return (float)obj.GetValue(PercentageProperty);
        }

        public static void SetPercentage(DependencyObject obj, float value)
        {
            obj.SetValue(PercentageProperty, value);
        }


        private static void OnPropertyChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            var target = o as TextBlock;

            if (target == null)
            {
                return;
            }

            var color1 = PercentageColor.GetColor1(o);
            var color2 = PercentageColor.GetColor2(o);
            var percentage = PercentageColor.GetPercentage(o);

            var brush = target.Foreground as LinearGradientBrush;

            if (brush == null)
            {
                var gradient = new LinearGradientBrush();
                gradient.EndPoint = new Point(1, 0);
                gradient.GradientStops.Add(new GradientStop(color1, 0));
                gradient.GradientStops.Add(new GradientStop(color1, percentage));
                gradient.GradientStops.Add(new GradientStop(color2, percentage));
                gradient.GradientStops.Add(new GradientStop(color2, 1));

                target.Foreground = gradient;
            }
            else
            {
                brush.GradientStops[0].Color = color1;
                brush.GradientStops[1].Color = color1;
                brush.GradientStops[1].Offset = percentage;
                brush.GradientStops[2].Color = color2;
                brush.GradientStops[2].Offset = percentage;
                brush.GradientStops[3].Color = color2;
            }
        }
    }

}
