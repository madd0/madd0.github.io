﻿//-----------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="">
//     Copyright (c) madd0, . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace PercentageColorDemo
{
    using System;
    using System.Linq;

    using System.Windows;
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:MainWindow"/> class.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();
        }
    }
}
